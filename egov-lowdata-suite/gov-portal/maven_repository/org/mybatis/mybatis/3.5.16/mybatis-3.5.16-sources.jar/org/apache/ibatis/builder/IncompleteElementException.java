/*
 *    Copyright 2009-2023 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.apache.ibatis.builder;

/**
 * @author Eduardo Macarron
 */
public class IncompleteElementException extends BuilderException {
  private static final long serialVersionUID = -3697292286890900315L;

  public IncompleteElementException() {
  }

  public IncompleteElementException(String message, Throwable cause) {
    super(message, cause);
  }

  public IncompleteElementException(String message) {
    super(message);
  }

  public IncompleteElementException(Throwable cause) {
    super(cause);
  }

}
